/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.utils;

import com.mycompany.ilib.Dashboard;
import java.sql.Connection; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import com.mycompany.db.Database;

/**
 *
 * @author 59169
 */
public class CLogin {
     public void validaUsuario(JTextField usuario, JPasswordField contrasenia){
            Database objetoConexion = new Database();
            Connection conexion = null;
        try {
            objetoConexion.Conectar();
            conexion = objetoConexion.getConexion();
           
            if (conexion != null) {
            
            String consulta="select * from Usuarios where Usuarios.ingresoUsuario =(?) and Usuarios.ingresoContrasenia=(?);";
            PreparedStatement ps = conexion.prepareStatement(consulta);
            
            
            String contra = String.valueOf(contrasenia.getPassword());
            
            ps.setString(1, usuario.getText());
            ps.setString(2,contra);
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                
                JOptionPane.showMessageDialog(null,"El Usuario es Correcto");
                Dashboard objetoMenu = new Dashboard();
                objetoMenu.setVisible(true);
            }
            else
            {
                JOptionPane.showMessageDialog(null,"El Usuario es INCORRECTO, VUELVA A INTENTAR");
            }
            rs.close();
            ps.close();
                objetoConexion.Cerrar();
            } else {
                JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos");
            }
            
      
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"ERROR: "+e.toString());
        }
        
    }
    
    
}
