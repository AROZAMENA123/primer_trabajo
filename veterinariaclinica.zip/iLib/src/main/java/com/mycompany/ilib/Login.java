package com.mycompany.ilib;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author 59169
 */
public class Login {

    public static void main(String[] args) {
        FormLogin objetoLogin = new FormLogin();
        objetoLogin.setVisible(true);
    }
}
