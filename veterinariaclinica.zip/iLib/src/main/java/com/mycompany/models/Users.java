package com.mycompany.models;

public class Users {
    private int id;
    private String name;
    private String last_name_p_m;
    private String ru;
    private String domicilio;
    private String tel;
    private int sanctions;
    private int sanc_money;

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLast_name_p_m(String last_name_p_m) {
        this.last_name_p_m = last_name_p_m;
    }

    public void setRu(String ru) {
        this.ru = ru;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public void setSanctions(int sanctions) {
        this.sanctions = sanctions;
    }

    public void setSanc_money(int sanc_money) {
        this.sanc_money = sanc_money;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLast_name_p_m() {
        return last_name_p_m;
    }

    public String getRu() {
        return ru;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public String getTel() {
        return tel;
    }

    public int getSanctions() {
        return sanctions;
    }

    public int getSanc_money() {
        return sanc_money;
    }
}
